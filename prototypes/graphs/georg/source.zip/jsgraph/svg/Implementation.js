/*
	Copyright (c) Georg Hackenberg, 2009

	This file is part of JSGraph.

	JSGraph is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	JSGraph is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with JSGraph.  If not, see <http://www.gnu.org/licenses/>.
	
	Questions: ghackenberg@gmail.com
*/

var svg = "http://www.w3.org/2000/svg";

// Data structures used by the algorithm.
var nodes = new Array();
var edges = new Array();
var weights = new Array();
var node_labels = new Array();
var edge_labels = new Array();
var edge_label_bbox = new Array();

// Position and force information.
var posx = new Array();
var posy = new Array();
var updatex = new Array();
var updatey = new Array();

// Distance error and random factor.
var distances = new Array();
var factors = new Array();

// Status variables.
var first_edge_label = null;
var first_edge_label_bbox = null;
var iteration_step = 0;
var interval = null;

// configuration parameters.
var stepsize = 0.25; // percentage of the force sum to use in each step
var randomsize = 0; // perturbation size in pixels for adding randomness
var width = 800; // width of the SVG canvas
var height = 600; // height of the SVG canvas
var move_threshold = 1; // percentage of nodes moved in each step
var edge_threshold = 1; // percentage of edges to consider in each step
var update_iterations = 1; // number of iterations per update

function createNode() {

	var canvas = document.getElementById("canvas");

	// Create the new node as an SVG circle.
	var node = document.createElementNS(svg, "circle");
	
	node.setAttribute("r", "10px");
	node.setAttribute("style", "fill: red; stroke: black; stroke-width: 1px;");
	
	posx[nodes.length] = Math.random() * width;
	posy[nodes.length] = Math.random() * height;
	
	node.setAttribute("cx", posx[nodes.length] + "px"); // random placement
	node.setAttribute("cy", posy[nodes.length] + "px"); // random placement
	
	canvas.appendChild(node);
	nodes.push(node);
	
	// Create node label.
	var text = document.createElementNS(svg, "text");
	text.appendChild(document.createTextNode(nodes.length));
	
	canvas.appendChild(text);
	node_labels.push(text);
	
	// Update the label position.
	updateMetaData();
	
	return nodes.length - 1;
}

function linkNodes(a, b, length) {
	
	var canvas = document.getElementById("canvas");
	
	// Check whether the data structures are initialized correctly.
	if (!weights[a]) {
		weights[a] = new Array();
		edges[a] = new Array();
		edge_labels[a] = new Array();
		edge_label_bbox[a] = new Array();
	}
	if (!weights[b]) {
		weights[b] = new Array();
		edges[b] = new Array();
		edge_labels[b] = new Array();
		edge_label_bbox[b] = new Array();
	}
	
	// Set the desired length of the link (bi-directional!).
	weights[a][b] = length;
	weights[b][a] = length;
	
	// Create the edge label (inserted before to be rendered on top of the line).
	var text = document.createElementNS(svg, "text");
	text.setAttribute("font-size", "9");
	text.appendChild(document.createTextNode("undefined"));
	
	edge_labels[a][b] = text;
	edge_labels[b][a] = text;
	
	canvas.insertBefore(text, first_edge_label ? first_edge_label : canvas.firstChild);
	
	if (!first_edge_label) {
		first_edge_label = text;
	}
	
	// Create the background rectangle.
	var bbox = document.createElementNS(svg, "rect");
	bbox.setAttribute("style", "fill: white; stroke: white; stroke-width: 10px;");
	
	edge_label_bbox[a][b] = bbox;
	edge_label_bbox[b][a] = bbox;
	
	canvas.insertBefore(bbox, first_edge_label_bbox ? first_edge_label_bbox : canvas.firstChild);
	
	if (!first_edge_label_bbox) {
		first_edge_label_bbox = bbox;
	}
	
	// Create the line object.
	var line = document.createElementNS(svg, "line");
	line.setAttribute("style", "stroke: black; stroke-width: 1px; stroke-dasharray: 5, 5;");
	
	edges[a][b] = line;
	edges[b][a] = line;
	
	canvas.insertBefore(line, canvas.firstChild);
	
	// Update the line and label position.
	updateMetaData();
}

function updateLayout() {
	
	for (var k = 0; k < update_iterations; k++) {
	
		// Calculate for all nodes the sum of forces which are working on them.
		for (var i = 0; i < nodes.length; i++) {
		
			/*
			var distsum = 0;
			*/
			
			factors[i] = randomsize;
		
			updatex[i] = 0;
			updatey[i] = 0;
			
			
			if (Math.random() < move_threshold) {
			
				// Check each other node for a link and calculate the force based on the desired length (and the connecting vector).
				for (var j = 0; j < nodes.length; j++) {
					if (Math.random() < edge_threshold && weights[i] && weights[i][j]) {
						// Calculate the connecting vector and its length.
						var diffx = posx[j] - posx[i];
						var diffy = posy[j] - posy[i];
						var distance = Math.sqrt(diffx * diffx + diffy * diffy);
						var length = distance - weights[i][j];
					
						/*
						distsum += distance;
						*/
						
						// Accumulate the final update based on the desired length.
						updatex[i] += length * diffx / distance;
						updatey[i] += length * diffy / distance;
					}
				}
				
			}
			
			// THE FOLLOWING COULD HELP IDENTIFYING CASES WHERE THE ALGORITHM IS TRAPPED IN LOCAL MINIMA.
			/*
			if (distsum > distances[i] && distsum > 100) {
				factors[i] = Math.sqrt(distsum);
			}
			
			distances[i] = distsum;
			*/
			
		}
		
		// Update the position of each node by taking a percentage of the update vector and some random perturbation.
		for (var i = 0; i < nodes.length; i++) {
			posx[i] += updatex[i] * stepsize + ((Math.random() - 0.5) * factors[i]);
			posy[i] += updatey[i] * stepsize + ((Math.random() - 0.5) * factors[i]);
			
			nodes[i].setAttribute("cx", posx[i] + "px");
			nodes[i].setAttribute("cy", posy[i] + "px");
		}
	
	}
	
	iteration_step++;
	
	updateMetaData();
}

function checkPositionUpdate(node, x, y) {
	var energy = 0;
	
	for (var i = 0; i < nodes.length; i++) {
		if (edges[node] && edges[node][i]) {
			var diffx = posx[i] - x;
			var diffy = posy[i] - y;
			var distance = Math.sqrt(diffx * diffx + diffy * diffy);
			var deviation = distance - weights[node][i];
			
			energy += Math.abs(deviation);
		}
	}
	
	return energy;
}

function updateMetaData() {
	var status = 0;

	for (var i = 0; i < nodes.length; i++) {
		for (var j = i + 1; j < nodes.length; j++) {
			if (edges[i] && edges[i][j]) {
				// Update the line points.
				edges[i][j].setAttribute("x1", nodes[i].getAttribute("cx"));
				edges[i][j].setAttribute("y1", nodes[i].getAttribute("cy"));
				edges[i][j].setAttribute("x2", nodes[j].getAttribute("cx"));
				edges[i][j].setAttribute("y2", nodes[j].getAttribute("cy"));
				
				// Calculate the new edge labels.
				var diffx = posx[j] - posx[i];
				var diffy = posy[j] - posy[i];
				var distance = Math.sqrt(diffx * diffx + diffy * diffy);
				var deviation = Math.round(distance - weights[i][j]);
				
				status += Math.abs(deviation);
				
				edge_labels[i][j].firstChild.nodeValue = deviation;
				
				// Set the edge label color based in the deviation value.
				var color = (deviation > 0) ? "green" : ((deviation < 0) ? "red" : "black");
				edge_labels[i][j].setAttribute("style", "fill: " + color + ";")
				
				// Move the edge labels.
				edge_labels[i][j].setAttribute("x", ((posx[i] + posx[j]) - edge_labels[i][j].getBBox().width) / 2 + "px");
				edge_labels[i][j].setAttribute("y", ((posy[i] + posy[j]) + edge_labels[i][j].getBBox().height) / 2 + "px");
				
				// Adapt the background rectangle for the edge label.
				edge_label_bbox[i][j].setAttribute("width", edge_labels[i][j].getBBox().width + "px");
				edge_label_bbox[i][j].setAttribute("height", edge_labels[i][j].getBBox().height + "px");
				
				edge_label_bbox[i][j].setAttribute("x", ((posx[i] + posx[j]) - edge_labels[i][j].getBBox().width) / 2 + "px");
				edge_label_bbox[i][j].setAttribute("y", ((posy[i] + posy[j]) - edge_labels[i][j].getBBox().height) / 2 + "px");
			}
		}
		
		// Move the node labels.
		node_labels[i].setAttribute("x", posx[i] - node_labels[i].getBBox().width / 2 + "px");
		node_labels[i].setAttribute("y", posy[i] + node_labels[i].getBBox().height / 2 + "px");
	}
	
	document.getElementById("status").innerHTML = "Total deviation: " + status + "<br/>Iteration step: " + iteration_step;
}

function displayComment(html) {

	// Set the content of the COMMENT element and display it.
	var div = document.getElementById("comment");
	
	div.innerHTML = html;
	div.style.display = "block";
	
}

function resetStatus() {
	first_edge_label = null;
	first_edge_label_bbox = null;
	iteration_step = 0;
}

function startAlgorithm() {
	if (interval) {
		stopAlgorithm();
	}

	// Start the animation/iteration.
	interval = window.setInterval(updateLayout, 40);
}

function stopAlgorithm() {
	window.clearInterval(interval);
	interval = null;
}
