/*
	Copyright (c) Georg Hackenberg, 2009

	This file is part of JSGraph.

	JSGraph is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	JSGraph is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with JSGraph.  If not, see <http://www.gnu.org/licenses/>.
	
	Questions: ghackenberg@gmail.com
*/

createNode();
createNode();
createNode();
createNode();
createNode();
createNode();
createNode();
createNode();
createNode();
createNode();

linkNodes(0,1,50);
linkNodes(0,2,50);
//linkNodes(0,4,100);
linkNodes(1,2,50);
linkNodes(1,3,50);
//linkNodes(1,5,100);
linkNodes(2,3,50);
linkNodes(2,4,50);
//linkNodes(2,6,100);
linkNodes(3,4,50);
linkNodes(3,5,50);
//linkNodes(3,7,100);
linkNodes(4,5,50);
linkNodes(4,6,50);
//linkNodes(4,8,100);
linkNodes(5,6,50);
linkNodes(5,7,50);
//linkNodes(5,9,100);
linkNodes(6,7,50);
linkNodes(6,8,50);
linkNodes(7,8,50);
linkNodes(7,9,50);
linkNodes(8,9,50);

displayComment("Additional forces for preventing the overlap of non-connected nodes could help solve the problem in this case.");
