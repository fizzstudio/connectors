/*
	Copyright (c) Georg Hackenberg, 2009

	This file is part of JSGraph.

	JSGraph is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	JSGraph is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with JSGraph.  If not, see <http://www.gnu.org/licenses/>.
	
	Questions: ghackenberg@gmail.com
*/

// Data structures used by the algorithm.
var nodes = new Array();
var links = new Array();
var updatex = new Array();
var updatey = new Array();
var distances = new Array();
var factors = new Array();

var width = 1000; // max x position for random initialization
var height = 600; // max y position for random initialization
var stepsize = 0.0005; // percentage of the force sum to use in each step
var randomsize = 1; // perturbation size in pixels for adding randomness

function createNode() {

	// Create the new node as HTML element.
	var node = document.createElement("div");
	
	// Store the node in the data structure.
	nodes.push(node);
	
	// Update some node properties for display.
	node.innerHTML = nodes.length;
	node.style.left = Math.random() * width; // random placement
	node.style.top = Math.random() * height; // random placement
	
	// Add the node to the HTML document tree.
	document.getElementById("canvas").appendChild(node);
	
	return nodes.length - 1;
}

function linkNodes(a, b, length) {
	// check whether the data structures are initialized correctly
	if (!links[a]) {
		links[a] = new Array();
	}
	if (!links[b]) {
		links[b] = new Array();
	}
	
	// set the desired length of the link (bi-directional!)
	links[a][b] = length;
	links[b][a] = length;
}

function updateLayout() {
	
	// Calculate for all nodes the sum of forces which are working on them.
	for (var i = 0; i < nodes.length; i++) {
	
		/*
		var distsum = 0;
		*/
		
		factors[i] = randomsize;
	
		updatex[i] = 0;
		updatey[i] = 0;
		
		// Check each other node for a link and calculate the force based on the desired length (and the connecting vector).
		for (var j = 0; j < nodes.length; j++) {
			if (links[i] && links[i][j]) {
				// Calculate the connecting vector and its length.
				var diffx = nodes[j].offsetLeft - nodes[i].offsetLeft;
				var diffy = nodes[j].offsetTop - nodes[i].offsetTop;
				var distance = Math.sqrt(diffx * diffx + diffy * diffy);
			
				/*
				distsum += distance;
				*/
				
				// Accumulate the final update based on the desired length.
				updatex[i] += (distance - links[i][j]) * diffx;
				updatey[i] += (distance - links[i][j]) * diffy;
			}
		}
		
		// THE FOLLOWING COULD HELP IDENTIFYING CASES WHERE THE ALGORITHM IS TRAPPED IN LOCAL MINIMA.
		/*
		if (distsum > distances[i] && distsum > 100) {
			factors[i] = Math.sqrt(distsum);
		}
		
		distances[i] = distsum;
		*/
		
	}
	
	// Update the position of each node by taking a percentage of the update vector and some random perturbation.
	for (var i = 0; i < nodes.length; i++) {
		nodes[i].style.left = nodes[i].offsetLeft + updatex[i] * stepsize + ((Math.random() - 0.5) * factors[i]);
		nodes[i].style.top = nodes[i].offsetTop + updatey[i] * stepsize + ((Math.random() - 0.5) * factors[i]);
	}
}

function displayComment(html) {

	// Set the content of the COMMENT element and display it.
	var div = document.getElementById("comment");
	
	div.innerHTML = html;
	div.style.display = "block";
	
}

// Start the animation/iteration.
window.setInterval(updateLayout, 1);
