/*
	Copyright (c) Georg Hackenberg, 2009

	This file is part of JSGraph.

	JSGraph is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	JSGraph is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with JSGraph.  If not, see <http://www.gnu.org/licenses/>.
	
	Questions: ghackenberg@gmail.com
*/

createNode();
createNode();
createNode();
createNode();
createNode();
createNode();
createNode();

linkNodes(0,1,430/4);
linkNodes(0,2,450/4);
linkNodes(0,3,800/4);
linkNodes(1,2,260/4);
linkNodes(1,3,420/4);
linkNodes(1,5,1000/4);
linkNodes(2,3,400/4);
linkNodes(2,4,720/4);
linkNodes(3,4,480/4);
linkNodes(3,5,640/4);
linkNodes(3,6,850/4);
linkNodes(4,5,670/4);
linkNodes(4,6,580/4);
linkNodes(5,6,470/4);

displayComment("This test case currently suffers from being stuck in a local minimum. The problem is, that nodes 2 and 3 should be interchanged.");
